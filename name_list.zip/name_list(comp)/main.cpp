#include <bits/stdc++.h>

using namespace std;

int main()
{
    freopen("input.txt","r",stdin);
    freopen("output.txt","w",stdout);
    string s,s1;
    int a=0;
    vector<string> v,v1;//compression
    getline(cin,s);
    while(s[0] !='0'){
        if(!a){
           v.push_back(s);
           a=1;
           s1=s;
        }
        else{
            int x=0,cnt=0,y;
            y=min(s1.size(),s.size());
            while(y--){
               if(s1[x]==s[x]) cnt++;
                else break;
                x++;
            }
            s1=s;
            if(cnt){
            s="";
            for(int i=cnt;i>0;i/=10){
            s+=(i%10)+'0';}
            reverse(s.begin(),s.end());
            s+=s1.substr(cnt,s1.size());
        }
        v.push_back(s);
    }
    getline(cin,s);
    }
    cout<<"The compressed file " <<endl;
    for(int i=0;i<v.size();i++){
        cout<<v[i]<<endl;
    }
    //decompression
    v1.push_back(v[0]);
    for(int i=1;i<v.size();i++){
        string ss=v[i],st="",ss1;
        for(int j=0;j<ss.size();j++){
        if(ss[j]>'0' && ss[j]<='9'){
            st+=ss[j];
        }
        else break;
        }
        int n=st.size()-1,z=0;
        for(int j=1;j<=st.size();j*=10){
             z+=(st[n]-'0')*j;
            n--;
        }
       ss1=v1[i-1];
       ss1=ss1.substr(0,z);
       ss=ss.substr(st.size(),ss.size());
       ss1+=ss;
       v1.push_back(ss1);
    }
    cout<<endl;
    cout<<"*****************************************************"<<endl;
    cout<<"The decompressed file " <<endl;

    for(int i=0;i<v1.size();i++){
        cout<<v1[i]<<endl;
    }
    return 0;
}
